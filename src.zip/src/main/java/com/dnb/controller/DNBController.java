package com.dnb.controller;

import java.util.Iterator;
import java.util.List;

import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import com.dnb.model.CustomerDetails;
import com.dnb.model.CustomerDetailsTable;
import com.dnb.model.CustomerPo;
import com.dnb.model.CustomerloginDetails;
import com.dnb.serviceimpl.CustomerDetailsImpl;

@Controller
@RequestMapping("/customer")
public class DNBController {
	@Autowired
	private CustomerDetailsImpl customerDetailsImpl;	
	
	@RequestMapping(value="/customerDetails", method = RequestMethod.GET)
	
	public @ResponseBody CustomerPo getCustomerDetails(@FormParam("name") String name,@FormParam("phoneNo") String phoneNo){
		System.out.println("inside customer details");	
        CustomerPo cusPo=new CustomerPo();
		try {
			cusPo= customerDetailsImpl.getCustomerDetails(name,phoneNo);
			if(cusPo !=null)
			
		return cusPo;
 } catch (Exception e){
			System.out.println("Exception"+e);
		}
     
		
	return cusPo;
	}
	@RequestMapping(value="/customerAddDetails", method = RequestMethod.GET)
	public  @ResponseBody String getCustomerAddDetails(@FormParam("custid") Integer custid, @FormParam("name") String name,@FormParam("phoneNo") String phoneNo,@FormParam("address") String address){
		System.out.println("inside customer details"+custid);
		System.out.println("inside customer details"+name);
		System.out.println("inside customer details"+phoneNo);
		System.out.println("inside customer details"+address);
		//System.out.println("inside customer details"+creationdate);
		//String name = "Senthil";
		CustomerDetails customerDetailsModel = new CustomerDetails();
		customerDetailsModel.setId(custid);
		customerDetailsModel.setName(name);
		customerDetailsModel.setPhone(phoneNo);
		customerDetailsModel.setAddress(address);
	//	customerDetailsModel.setCreationdate(creationdate);
		
		String message = customerDetailsImpl.addCustomerDetails(customerDetailsModel);
		
	return message;
	}
	@RequestMapping(value="/customerDeleteDetails", method = RequestMethod.GET)
	public  @ResponseBody String getCustomerAddDetails(@FormParam("custid") Integer custid){
		System.out.println("inside customer details"+custid);	
	
		
		String message = customerDetailsImpl.deleteCustomerDetails(custid);
		
	return message;
	}

}
