package com.dnb.model;

import org.springframework.beans.factory.annotation.Autowired;

public class CustomerDetailsTable {
	@Autowired
private CustomerDetails custDetails;
	@Autowired
	private CustomerloginDetails cusLogDetails;
	@Autowired
private custinterest custInterest;
	public CustomerDetails getCustDetails() {
		return custDetails;
	}
	public void setCustDetails(CustomerDetails custDetails) {
		this.custDetails = custDetails;
	}
	public CustomerloginDetails getCusLogDetails() {
		return cusLogDetails;
	}
	public void setCusLogDetails(CustomerloginDetails cusLogDetails) {
		this.cusLogDetails = cusLogDetails;
	}
	public custinterest getCustInterest() {
		return custInterest;
	}
	public void setCustInterest(custinterest custInterest) {
		this.custInterest = custInterest;
	}
	public CustomerDetailsTable(CustomerDetails a,CustomerloginDetails b,custinterest c)
	{
		
	}
	}

