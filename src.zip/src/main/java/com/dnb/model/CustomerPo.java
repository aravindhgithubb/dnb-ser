package com.dnb.model;



public class CustomerPo {
	private  CustomerDetails custDet;

	public CustomerPo() {
		// TODO Auto-generated constructor stub
	}

	public CustomerDetails getCustDet() {
		return custDet;
	}

	public void setCustDet(CustomerDetails custDet) {
		this.custDet = custDet;
	}
}
	
  